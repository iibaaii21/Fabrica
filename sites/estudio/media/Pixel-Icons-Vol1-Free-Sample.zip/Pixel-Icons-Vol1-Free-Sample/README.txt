PIXEL ICONS VOL. 1 - 73 original 16x16 pixel-art icons

FOLDERS
- png-16px / png-32px / png-64px : one transparent PNG per icon, pre-scaled with nearest-neighbor.
- spritesheet-16px.png / spritesheet-64px.png : all icons in one sheet, 16 per row.
- spritesheet-16px.json / spritesheet-64px.json : atlas with x, y, w, h for every icon by name.

IMPORT SETTINGS (keep pixels crisp)
- Godot 4: Import tab > Texture > Filter: Nearest (or Project Settings > Rendering > Textures > Default Texture Filter: Nearest). Use AtlasTexture regions from the JSON for the spritesheet.
- Unity: Texture Type: Sprite (2D and UI) · Filter Mode: Point (no filter) · Compression: None · Pixels Per Unit: 16. For the sheet: Sprite Mode Multiple > Slice > Grid By Cell Size 16x16.
- GameMaker: create a Sprite from the PNG, or import the sheet with Import Strip Image (16 per row, 16x16).
- HTML5 canvas: ctx.imageSmoothingEnabled = false; drawImage(sheet, x, y, w, h, dx, dy, w*scale, h*scale) with the JSON values. In CSS use image-rendering: pixelated.

LICENSE: see LICENCIA.txt (commercial use allowed, no attribution required, no resale of the icons themselves).

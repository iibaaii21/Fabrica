SOFT UI SOUNDS VOL. 2
46 soft interface sounds, 44.1 kHz / 16-bit mono WAV, trimmed and normalized.

Folders by name prefix:
  click_ hover_ slider_   - buttons, hover, slider ticks
  toggle_on_ toggle_off_  - switches
  confirm_ cancel_ back_ error_
  notify_ message_        - notifications and chat
  open_ close_            - panels, menus, popups
  type_ copy_ delete_     - typing and editing
  reward_ purchase_ unlock_ complete_

Tip: play typing and hover sounds at 60-80 % volume and vary the pitch slightly (0.95-1.05) so repeats feel natural.
Works in Godot, Unity, GameMaker, Construct, Phaser and any engine that plays WAV.
